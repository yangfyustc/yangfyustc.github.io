これはChinese Journal of GalgameのLaTeXテンプレートのREADMEファイルです。

zipファイルには以下が含まれています：

 - cjgtemplateフォルダ（cjgtemplate.tex、revtex4-1.cls、cjg4-1.rtxが含まれています。）

 - cjgsampleフォルダ（テンプレートの例）


以下のファイルはcjcptemplateフォルダと同じフォルダにないと正しくコンパイルできません：

 - revtex4-1.cls

 - cjg4-1.rtx

 - cjgtemplate.tex

 - 参考文献.bib
 
 - あなたのフィギュア



このテンプレートを使うには、ドキュメントクラス 「revtex4-1」を読み込み、ドキュメントクラスオプション「cjg」を追加します：  \documentclass[cjg]{revtex4-1}のように。



CJGのLaTeXテンプレートを使用する際に不明な点がありましたら、お気軽にCJG編集部までお問い合わせください。
電子メール：yangfyustc@mail.ustc.edu.cn